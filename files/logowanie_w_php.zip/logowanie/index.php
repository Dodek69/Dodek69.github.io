<?php

	session_start();
	
	if ((isset($_SESSION['zalogowany'])) && ($_SESSION['zalogowany']==true))
	{
		header('Location: php/vip.php');
		exit();
	}

?>

<!DOCTYPE HTML>
<html>
    
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
        <meta http-equiv="Content-Language" content="pl" />
        <meta name="Author" content="Dominik Ciolczyk" />
        <meta name="Description" content="Login page" />
        <meta name="Keywords" content="form, login, ideas, programming, Dodek, Dodek69" />
        <meta name="Robots" content="index, nofollow" />
        <meta name="Googlebot" content="index, nofollow" />
        <meta name="Generator" content="Brackets" />
        <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1" />
        
        <link rel="stylesheet" type="text/css" href="css/style.css">
        <link href="icons/css/all.css" rel="stylesheet">
        <link rel="icon" href="img/sql.png">
        
        <title>Wymagane logowanie</title>
        
    </head>

    <body>

        <div id="logbox">

          <form action="php/logowanie.php" method="post" name='form-login'>
              
            <h2>Zaloguj się, aby kontynuować...</h2>

            <span><i class="fas fa-user"></i></span>

            <input type="text" name="login" placeholder="Login">

            <span><i class="fas fa-lock"></i></span>
              
            <input type="password" name="haslo" placeholder="Hasło">

            <input type="submit" value="Wejdź">

    </form>

    <?php
            
        if(isset($_SESSION['blad']))
        {
            echo $_SESSION['blad'];
        } 
            
    ?>
            </div>

    </body>
</html>