<?php

	session_start();
	
	if (!isset($_SESSION['zalogowany']))
	{
		header('Location: ../index.php');
		exit();
	}
	
?>

<!DOCTYPE HTML>
<html>
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
        <meta http-equiv="Content-Language" content="pl" />
        <meta name="Author" content="Dominik Ciolczyk" />        
        <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1" />
        
        <link rel="stylesheet" type="text/css" href="../css/style_vip.css">
        <link href="../icons/css/all.css" rel="stylesheet">
        <link rel="icon" href="../img/sql.png">
        
	   <title>Jesteś zalogowany</title>
    </head>

    <body>

        <div id="login">

          <form action="wyloguj.php" method="post" name='form-login'>

            <h2>Zalogowano jako:</h2>

            <span><i class="fas fa-user"></i></span>

            <input type="text" placeholder=
                   
                    <?php 
                     echo $_SESSION['user'];
                     ?> 
                   
                   readonly="readonly">


            <span><i class="fas fa-at"></i></span>

              <input type="text" placeholder=
                     
                    <?php 
                    echo $_SESSION['email'];
                    ?> 
                     
                readonly="readonly">

              <input type="submit" value="Wyloguj">

            </form>
            
        </div>
        
    </body>
    
</html>